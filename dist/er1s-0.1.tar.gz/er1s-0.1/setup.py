from setuptools import setup

setup(name='er1s',
      version='0.1',
      description='er1s',
      url='http://github.com/eris9/eris9',
      author='Eris9/Sakurai07',
      author_email='blzzardst0rm@gmail.com',
      license='MIT',
      packages=['er1s'],
      zip_safe=False)